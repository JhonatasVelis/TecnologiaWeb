function enviar() {

    var nome = document.getElementById("nome").value;
    var idade = document.getElementById("idade").value;
    var peso = document.getElementById("peso").value;
   
    if (nome != "" && idade > 18 && peso < 90) {
        
        console.log("OK");

    } else {

        console.log("NOK");

    }

}