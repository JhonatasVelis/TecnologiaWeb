function outros()
{
    if(document.getElementById("outros").checked == true)
    {
       var outros = document.getElementsByClassName("outrosGeneros");
       for(var i = 0;i < outros.length; i++)
       {
           outros[i].checked = false;
       }
    }
}

function demaisGeneros()
{
    document.getElementById("outros").checked = false;
}